import java.io.*;  


import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse; 
 
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet  {    
	
     public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException 
      {  
         PrintWriter out = res.getWriter();  
         res.setContentType("text/html");  
         out.println("<html><body>");  
         try 
         {  
        	 Class.forName("com.mysql.jdbc.Driver");
 			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Employee","root","root@1234");
 			 
 		
 			PreparedStatement stmt = con.prepareStatement("insert into employee(name,email,salary) values('Emp2','Emp2@gmail.com','12000')"); 
             
             stmt.executeUpdate();
             out.println("Added"); 
             con.close();  
            }  
             catch (Exception e) 
            {  
             out.println("error");  
         }  
     }  
 }  
