import java.io.*;  
import java.sql.*;  
 
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;  
@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet  {    
	
     public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException 
      {  
         PrintWriter out = res.getWriter();  
         res.setContentType("text/html");  
         out.println("<html><body>");  
         try 
         {  
        	 Class.forName("com.mysql.jdbc.Driver");
 			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Employee","root","root@1234");
 			 
 	
 			PreparedStatement st = con.prepareStatement("delete from employee WHERE name ='Emp3'");
   
              
             st.executeUpdate();
             
  
             out.println("Deleted successfully!");
             st.close();
             con.close();
   
             // Get a writer pointer 
             // to display the successful result
                    } catch (Exception e) {  
             out.println("error");  
         }  
     }  
 }  